#ifndef LIBSSH2

#define LIBSSH2
#define LIBSSH2LIBNAME "libssh2"

int luaopen_libssh2 (lua_State *L);

#endif
