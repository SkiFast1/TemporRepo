#ifndef NSE_PCRELIB
#define NSE_PCRELIB

#define NSE_PCRELIBNAME "pcre"

LUALIB_API int luaopen_pcrelib (lua_State *L);

#endif

