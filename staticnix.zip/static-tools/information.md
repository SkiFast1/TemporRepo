# Information
The scripts included here are from the latest(7.11) version of nmap however the nmap binary has not been compiled with the scripting engine as it isn't possible to do so yet...

Work-In-Progress
================

Open to suggestion of how to compile scripting engine statically too though.
