--This is a --lua-exec "Hello world" example. In order to send to a client,
--all you need to do is output it to the standard output.

print "Hello, world!"
