--Emulates the daytime service (RFC 867).

print(os.date())
